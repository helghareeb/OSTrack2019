// Select the starting point and find its siblings.


// Change the values of the siblings' class attributes.
