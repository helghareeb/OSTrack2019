// Select the element and store it in a variable.


// Change the value of the class attribute.
