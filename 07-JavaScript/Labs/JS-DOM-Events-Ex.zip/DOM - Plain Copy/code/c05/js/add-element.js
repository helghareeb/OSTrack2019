// Create a new element and store it in a variable.


// Create a text node and store it in a variable.


// Attach the new text node to the new element.


// Find the position where the new element should be added.


// Insert the new element into its position.
