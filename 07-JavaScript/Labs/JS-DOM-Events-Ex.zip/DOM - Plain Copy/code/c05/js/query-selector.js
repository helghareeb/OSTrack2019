// querySelector only returns the first match.


// querySelectorAll returns a NodeList.
// The third li element is then selected and changed.
