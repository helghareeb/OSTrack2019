// Store the element to be removed in a variable.


// Find the element which contains the element to be removed.


// Remove the element.
