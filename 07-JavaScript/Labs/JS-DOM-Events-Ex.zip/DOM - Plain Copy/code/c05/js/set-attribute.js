// Get the first item

// Change its class attribute

// Get fourth item
// NOTE: The following line should say fourthItem (not el2)

// Add an attribute to it