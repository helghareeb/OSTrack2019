// Select the starting point and find its children.

// Change the values of the children's class attributes.
