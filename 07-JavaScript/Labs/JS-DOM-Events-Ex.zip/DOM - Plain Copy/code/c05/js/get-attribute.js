// Get first list item 

// If it has class attribute

// Get the attribute

// Add the value of the attribute after the list
  