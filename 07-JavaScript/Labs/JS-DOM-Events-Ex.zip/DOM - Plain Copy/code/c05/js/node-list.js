// Store NodeList in array

// If it contains items

 // Loop through each item

// Change value of class attribute
 