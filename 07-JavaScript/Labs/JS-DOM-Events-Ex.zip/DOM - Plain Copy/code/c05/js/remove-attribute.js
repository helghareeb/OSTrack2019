// Get the first item

// If it has a class attribute

// Remove its class attribute
