// Find hot items

// If 3 or more are found

// Select the third one from the NodeList

// Change the value of its class attribute

