// Get second list item

// Get its text content

// Change pine nuts to kale

// Update the list item