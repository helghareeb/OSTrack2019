// Store the first list item in a variable


// Get the content of the first list item


// Update the content of the first list item so it is a link
