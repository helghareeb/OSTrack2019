// Find first list item

// Get value of textContent

// Get value of innerText

// Show the content of these two properties at the end of the list

// Update the first list item