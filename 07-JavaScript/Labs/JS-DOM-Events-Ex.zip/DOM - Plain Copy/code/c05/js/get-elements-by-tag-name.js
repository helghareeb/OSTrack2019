// Find <li> elements

// If 1 or more are found

// Select the first one using array syntax

// Change the value of the class attribute

