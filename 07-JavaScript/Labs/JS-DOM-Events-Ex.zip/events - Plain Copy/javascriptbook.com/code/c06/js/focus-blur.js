function checkUsername() {// Declare function
  var username =  // Store username in variable
  if (username.length < 5) {  // If username < 5 characters
    elMsg // Change class on message
    elMsg// Update message
  } else {    // Otherwise
    elMsg // Clear the message
  }
}

function tipUsername() {// Declare function
  elMsg // Change class for message
  elMsg// Add message
}

var el = document. // Username input
var elMsg = document.// Element to hold message

// When the username input gains / loses focus call functions above:
 // focus call tipUsername()

// blur call checkUsername()

