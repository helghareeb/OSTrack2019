function setup() { // Declare function
  var textInput;  // Create variable
  textInput =  // Get username input
  textInput. // Give username focus
}

window.addEventListener('', setup, false); // When page loaded call setup()


