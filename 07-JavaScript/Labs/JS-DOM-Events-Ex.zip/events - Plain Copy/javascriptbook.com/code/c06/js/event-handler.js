function checkUsername() { // Declare function
  var elMsg =  // Get feedback element
  if (< 5) {  // If username too short
     // Set msg
  } else {                                            // Otherwise
    // Clear message
  }
}

 // Get username input

// When it loses focus call checkuserName()